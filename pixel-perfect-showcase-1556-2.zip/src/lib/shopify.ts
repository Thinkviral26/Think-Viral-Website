import { useEffect, useState } from "react";

export const SHOPIFY_API_VERSION = "2025-07";
export const SHOPIFY_STORE_PERMANENT_DOMAIN = "dcdanc-f1.myshopify.com";
const SHOPIFY_STOREFRONT_URL = `https://${SHOPIFY_STORE_PERMANENT_DOMAIN}/api/${SHOPIFY_API_VERSION}/graphql.json`;
// Public storefront token (safe for browser use)
const SHOPIFY_STOREFRONT_TOKEN = "cb8c10881f10ef2e8e88dd06b2d5f3fe";

export type Money = { amount: string; currencyCode: string };
export type ShopifyVariant = {
  id: string;
  title: string;
  price: Money;
  compareAtPrice: Money | null;
  availableForSale: boolean;
  selectedOptions: { name: string; value: string }[];
};
export type ShopifyProduct = {
  id: string;
  title: string;
  description: string;
  handle: string;
  images: { url: string; altText: string | null }[];
  variants: ShopifyVariant[];
  options: { name: string; values: string[] }[];
};

export async function storefrontApiRequest(query: string, variables: Record<string, unknown> = {}) {
  const res = await fetch(SHOPIFY_STOREFRONT_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Shopify-Storefront-Access-Token": SHOPIFY_STOREFRONT_TOKEN,
    },
    body: JSON.stringify({ query, variables }),
  });
  if (res.status === 402) {
    const { toast } = await import("sonner");
    toast.error("Shopify: Payment required", {
      description: "Your Shopify store needs an active plan. Visit admin.shopify.com to upgrade.",
    });
    return null;
  }
  if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
  const data = await res.json();
  if (data.errors) throw new Error(data.errors.map((e: { message: string }) => e.message).join(", "));
  return data;
}

const PRODUCT_FIELDS = `
  id title description handle
  images(first: 10) { edges { node { url altText } } }
  variants(first: 20) { edges { node {
    id title availableForSale
    price { amount currencyCode }
    compareAtPrice { amount currencyCode }
    selectedOptions { name value }
  } } }
  options { name values }
`;

type RawProduct = Omit<ShopifyProduct, "images" | "variants"> & {
  images: { edges: { node: ShopifyProduct["images"][number] }[] };
  variants: { edges: { node: ShopifyVariant }[] };
};
const normalize = (p: RawProduct): ShopifyProduct => ({
  ...p,
  images: p.images.edges.map((e) => e.node),
  variants: p.variants.edges.map((e) => e.node),
});

export async function fetchProductByHandle(handle: string) {
  const data = await storefrontApiRequest(
    `query($handle: String!) { product(handle: $handle) { ${PRODUCT_FIELDS} } }`,
    { handle },
  );
  const p = data?.data?.product as RawProduct | null | undefined;
  return p ? normalize(p) : null;
}

export async function fetchProducts(first = 20) {
  const data = await storefrontApiRequest(
    `query($first: Int!) { products(first: $first) { edges { node { ${PRODUCT_FIELDS} } } } }`,
    { first },
  );
  const edges = (data?.data?.products?.edges ?? []) as { node: RawProduct }[];
  return edges.map((e) => normalize(e.node));
}

export function useShopifyProduct(handle: string) {
  const [product, setProduct] = useState<ShopifyProduct | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let alive = true;
    fetchProductByHandle(handle)
      .then((p) => alive && setProduct(p))
      .catch((e) => console.error("Failed to load product", e))
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
  }, [handle]);
  return { product, loading };
}

export function useShopifyProducts() {
  const [products, setProducts] = useState<ShopifyProduct[] | null>(null);
  useEffect(() => {
    fetchProducts()
      .then(setProducts)
      .catch((e) => {
        console.error("Failed to load products", e);
        setProducts([]);
      });
  }, []);
  return products;
}

// ---------- Cart API ----------
const LINES = `lines(first: 100) { edges { node { id merchandise { ... on ProductVariant { id } } } } }`;
const CART_QUERY = `query cart($id: ID!) { cart(id: $id) { id totalQuantity } }`;
const CART_CREATE = `mutation cartCreate($input: CartInput!) { cartCreate(input: $input) { cart { id checkoutUrl ${LINES} } userErrors { field message } } }`;
const CART_ADD = `mutation cartLinesAdd($cartId: ID!, $lines: [CartLineInput!]!) { cartLinesAdd(cartId: $cartId, lines: $lines) { cart { id ${LINES} } userErrors { field message } } }`;
const CART_UPDATE = `mutation cartLinesUpdate($cartId: ID!, $lines: [CartLineUpdateInput!]!) { cartLinesUpdate(cartId: $cartId, lines: $lines) { cart { id } userErrors { field message } } }`;
const CART_REMOVE = `mutation cartLinesRemove($cartId: ID!, $lineIds: [ID!]!) { cartLinesRemove(cartId: $cartId, lineIds: $lineIds) { cart { id } userErrors { field message } } }`;

type UserError = { field: string[] | null; message: string };
type LineEdge = { node: { id: string; merchandise: { id: string } } };

function formatCheckoutUrl(url: string) {
  try {
    const u = new URL(url);
    u.searchParams.set("channel", "online_store");
    return u.toString();
  } catch {
    return url;
  }
}
const notFound = (errs: UserError[]) =>
  errs.some((e) => /cart not found|does not exist/i.test(e.message));

export async function createShopifyCart(variantId: string, quantity: number) {
  const data = await storefrontApiRequest(CART_CREATE, {
    input: { lines: [{ quantity, merchandiseId: variantId }] },
  });
  const r = data?.data?.cartCreate;
  if (!r || r.userErrors?.length) {
    console.error("Cart creation failed:", r?.userErrors);
    return null;
  }
  const lineId = r.cart.lines.edges[0]?.node?.id as string | undefined;
  if (!r.cart.checkoutUrl || !lineId) return null;
  return { cartId: r.cart.id as string, checkoutUrl: formatCheckoutUrl(r.cart.checkoutUrl), lineId };
}

export async function addLineToShopifyCart(cartId: string, variantId: string, quantity: number) {
  const data = await storefrontApiRequest(CART_ADD, {
    cartId,
    lines: [{ quantity, merchandiseId: variantId }],
  });
  const errs: UserError[] = data?.data?.cartLinesAdd?.userErrors ?? [];
  if (notFound(errs)) return { success: false, cartNotFound: true };
  if (errs.length || !data) return { success: false };
  const edges: LineEdge[] = data.data.cartLinesAdd.cart.lines.edges;
  return { success: true, lineId: edges.find((l) => l.node.merchandise.id === variantId)?.node.id };
}

export async function updateShopifyCartLine(cartId: string, lineId: string, quantity: number) {
  const data = await storefrontApiRequest(CART_UPDATE, { cartId, lines: [{ id: lineId, quantity }] });
  const errs: UserError[] = data?.data?.cartLinesUpdate?.userErrors ?? [];
  if (notFound(errs)) return { success: false, cartNotFound: true };
  return { success: !!data && errs.length === 0 };
}

export async function removeLineFromShopifyCart(cartId: string, lineId: string) {
  const data = await storefrontApiRequest(CART_REMOVE, { cartId, lineIds: [lineId] });
  const errs: UserError[] = data?.data?.cartLinesRemove?.userErrors ?? [];
  if (notFound(errs)) return { success: false, cartNotFound: true };
  return { success: !!data && errs.length === 0 };
}

export async function fetchCartQuantity(cartId: string) {
  const data = await storefrontApiRequest(CART_QUERY, { id: cartId });
  if (!data) return undefined;
  return (data.data?.cart?.totalQuantity as number | undefined) ?? 0;
}
