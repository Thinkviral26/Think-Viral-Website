import { useEffect, type ReactNode } from "react";
import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import {
  addLineToShopifyCart,
  createShopifyCart,
  fetchCartQuantity,
  removeLineFromShopifyCart,
  updateShopifyCartLine,
} from "./shopify";

export type CartItem = {
  key: string; // Shopify variant GID
  lineId: string | null;
  name: string;
  color: string;
  price: number;
  qty: number;
  image: string;
};

type AddInput = Omit<CartItem, "key" | "lineId"> & { variantId: string };

type CartStore = {
  items: CartItem[];
  cartId: string | null;
  checkoutUrl: string | null;
  isOpen: boolean;
  isLoading: boolean;
  isSyncing: boolean;
  open: () => void;
  close: () => void;
  add: (item: AddInput) => Promise<void>;
  setQty: (key: string, qty: number) => Promise<void>;
  remove: (key: string) => Promise<void>;
  clear: () => void;
  sync: () => Promise<void>;
};

export const useCartStore = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      cartId: null,
      checkoutUrl: null,
      isOpen: false,
      isLoading: false,
      isSyncing: false,
      open: () => set({ isOpen: true }),
      close: () => set({ isOpen: false }),
      clear: () => set({ items: [], cartId: null, checkoutUrl: null }),

      add: async ({ variantId, ...item }) => {
        const { items, cartId, clear } = get();
        const existing = items.find((i) => i.key === variantId);
        set({ isLoading: true });
        try {
          if (!cartId) {
            const r = await createShopifyCart(variantId, item.qty);
            if (r)
              set({
                cartId: r.cartId,
                checkoutUrl: r.checkoutUrl,
                items: [{ ...item, key: variantId, lineId: r.lineId }],
              });
          } else if (existing?.lineId) {
            const qty = existing.qty + item.qty;
            const r = await updateShopifyCartLine(cartId, existing.lineId, qty);
            if (r.success) set({ items: get().items.map((i) => (i.key === variantId ? { ...i, qty } : i)) });
            else if (r.cartNotFound) clear();
          } else {
            const r = await addLineToShopifyCart(cartId, variantId, item.qty);
            if (r.success)
              set({ items: [...get().items, { ...item, key: variantId, lineId: r.lineId ?? null }] });
            else if (r.cartNotFound) clear();
          }
        } catch (e) {
          console.error("Failed to add item:", e);
        } finally {
          set({ isLoading: false });
        }
      },

      setQty: async (key, qty) => {
        if (qty <= 0) return get().remove(key);
        const { items, cartId, clear } = get();
        const item = items.find((i) => i.key === key);
        if (!item?.lineId || !cartId) return;
        set({ isLoading: true });
        try {
          const r = await updateShopifyCartLine(cartId, item.lineId, qty);
          if (r.success) set({ items: get().items.map((i) => (i.key === key ? { ...i, qty } : i)) });
          else if (r.cartNotFound) clear();
        } finally {
          set({ isLoading: false });
        }
      },

      remove: async (key) => {
        const { items, cartId, clear } = get();
        const item = items.find((i) => i.key === key);
        if (!item?.lineId || !cartId) return;
        set({ isLoading: true });
        try {
          const r = await removeLineFromShopifyCart(cartId, item.lineId);
          if (r.success) {
            const next = get().items.filter((i) => i.key !== key);
            if (next.length === 0) clear();
            else set({ items: next });
          } else if (r.cartNotFound) clear();
        } finally {
          set({ isLoading: false });
        }
      },

      sync: async () => {
        const { cartId, isSyncing, clear } = get();
        if (!cartId || isSyncing) return;
        set({ isSyncing: true });
        try {
          const qty = await fetchCartQuantity(cartId);
          if (qty === 0) clear();
        } catch (e) {
          console.error("Failed to sync cart:", e);
        } finally {
          set({ isSyncing: false });
        }
      },
    }),
    {
      name: "shopify-cart",
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => ({ items: s.items, cartId: s.cartId, checkoutUrl: s.checkoutUrl }),
    },
  ),
);

export function useCartSync() {
  const sync = useCartStore((s) => s.sync);
  useEffect(() => {
    sync();
    const onVis = () => document.visibilityState === "visible" && sync();
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, [sync]);
}

/** Kept for existing page structure; syncs the Shopify cart. */
export function CartProvider({ children }: { children: ReactNode }) {
  useCartSync();
  return <>{children}</>;
}

export function useCart() {
  const s = useCartStore();
  return {
    ...s,
    count: s.items.reduce((n, i) => n + i.qty, 0),
    subtotal: s.items.reduce((n, i) => n + i.qty * i.price, 0),
  };
}
