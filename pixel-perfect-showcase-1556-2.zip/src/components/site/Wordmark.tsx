import { cn } from "@/lib/utils";
import logoAsset from "@/assets/thinkviral-logo.png.asset.json";

/** Shared THINKVIRAL logo used across navigation, loading, and footer placements. */
export function Wordmark({ className }: { className?: string }) {
  return (
    <img
      src={logoAsset.url}
      alt="THINKVIRAL"
      className={cn("block h-auto w-32 select-none object-contain", className)}
      draggable={false}
    />
  );
}
