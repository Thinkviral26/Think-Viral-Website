import { Wordmark } from "./Wordmark";

const columns = [
  { title: "Shop", links: [{ label: "Earbuds", href: "#shop" }, { label: "Features", href: "#features" }, { label: "FAQ", href: "#faq" }] },
  { title: "Support", links: [{ label: "Shipping", href: "#faq" }, { label: "Returns", href: "#faq" }, { label: "Contact", href: "#faq" }] },
  { title: "Social", links: [{ label: "Instagram", href: "#" }, { label: "Facebook", href: "#" }, { label: "Email", href: "#" }] },
];

export function Footer() {
  return (
    <footer className="border-t border-hairline-dark bg-ink pt-16 pb-8 text-paper">
      <div className="mx-auto max-w-[1600px] px-5 md:px-10">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_2fr]">
          <div>
            <Wordmark className="w-48 md:w-60" />
            <p className="display mt-6 text-2xl text-grey md:text-3xl">
              <span className="block">Think different.</span>
              <span className="block">Buy smart.</span>
            </p>
          </div>

          <div className="grid gap-10 sm:grid-cols-3">
            {columns.map((col) => (
              <div key={col.title}>
                <p className="label-mono text-paper/50">{col.title}</p>
                <ul className="mt-5 space-y-3">
                  {col.links.map((link) => (
                    <li key={link.label}>
                      <a
                        href={link.href}
                        className="inline-block py-1 text-sm text-paper/80 transition-colors hover:text-rgb-cyan"
                      >
                        {link.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16 flex flex-col gap-3 border-t border-hairline-dark pt-6 sm:flex-row sm:items-center sm:justify-between">
          <p className="label-mono text-paper/50">© 2026 THINKVIRAL. All rights reserved.</p>
          <p className="label-mono text-paper/50">India · UPI · Cards</p>
        </div>
      </div>
    </footer>
  );
}
