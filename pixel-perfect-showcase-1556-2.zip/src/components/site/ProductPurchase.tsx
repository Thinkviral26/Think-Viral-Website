import { useState } from "react";
import { ChevronLeft, ChevronRight, Minus, Plus } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { formatPrice, product } from "@/data/product";
import { useShopifyProduct } from "@/lib/shopify";
import { useCart } from "@/lib/cart";
import { MagneticButton } from "./MagneticButton";
import { Reveal } from "./Reveal";

export function ProductPurchase() {
  const [active, setActive] = useState(0);
  const [color, setColor] = useState<string>(product.colors[0]?.name ?? "Black");
  const [qty, setQty] = useState(1);
  const { add, open, isLoading } = useCart();
  const { product: live, loading } = useShopifyProduct(product.id);

  const images = live?.images.length
    ? live.images.map((img, i) => ({ src: img.url, alt: img.altText ?? `${live.title} image ${i + 1}` }))
    : product.images;
  const variant =
    live?.variants.find((v) => v.selectedOptions.some((o) => o.value === color)) ?? live?.variants[0];
  const price = variant ? Number(variant.price.amount) : product.price;
  const compareAt = variant?.compareAtPrice ? Number(variant.compareAtPrice.amount) : product.compareAtPrice;
  const colors = live
    ? (live.options.find((o) => /colou?r/i.test(o.name))?.values ?? []).map(
        (name) => product.colors.find((c) => c.name === name) ?? { name, swatch: "#888" },
      )
    : product.colors;
  const description = live?.description || product.description;
  const available = !!variant?.availableForSale;

  const addToCart = async () => {
    if (!variant || !live) return;
    await add({
      variantId: variant.id,
      name: live.title,
      color,
      price,
      qty,
      image: images[0]?.src ?? "",
    });
    toast("Added to cart.");
  };

  const buyNow = async () => {
    await addToCart();
    open();
  };

  const showPrevious = () => {
    setActive((current) => (current - 1 + images.length) % images.length);
  };

  const showNext = () => {
    setActive((current) => (current + 1) % images.length);
  };

  return (
    <section className="relative overflow-hidden bg-paper py-16 md:py-24">
      {/* Ambient backdrop */}
      <div aria-hidden className="pointer-events-none absolute inset-0 opacity-[0.35]">
        <div className="ambient-rgb absolute inset-[-20%]" />
      </div>

      <div className="relative mx-auto max-w-[1400px] px-5 md:px-10">
        <div className="grid gap-6 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)] lg:items-start lg:gap-10">
          {/* ============ Gallery ============ */}
          <Reveal className="order-1 lg:sticky lg:top-28">
            <div className="glass-frost rounded-3xl p-3 md:p-4">
              <div className="relative aspect-square overflow-hidden rounded-2xl bg-paper-soft">
                {images.map((img, i) => (
                  <img
                    key={img.alt}
                    src={img.src}
                    alt={img.alt}
                    loading="lazy"
                    className={cn(
                      "absolute inset-0 h-full w-full object-cover transition-[opacity,transform] duration-700 ease-out",
                      i === active ? "scale-100 opacity-100" : "pointer-events-none scale-[1.02] opacity-0",
                    )}
                  />
                ))}

                <div className="glass-dark absolute inset-x-3 bottom-3 flex items-center justify-between rounded-2xl px-4 py-2.5">
                  <span className="label-mono text-paper">
                    {String(active + 1).padStart(2, "0")} / {String(images.length).padStart(2, "0")}
                  </span>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={showPrevious}
                      aria-label="Show previous product image"
                      className="flex size-9 items-center justify-center rounded-full border border-white/20 text-paper transition-colors hover:bg-white/10 focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-white"
                    >
                      <ChevronLeft className="size-4" strokeWidth={1.5} />
                    </button>
                    <button
                      type="button"
                      onClick={showNext}
                      aria-label="Show next product image"
                      className="flex size-9 items-center justify-center rounded-full border border-white/20 text-paper transition-colors hover:bg-white/10 focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-white"
                    >
                      <ChevronRight className="size-4" strokeWidth={1.5} />
                    </button>
                  </div>
                </div>
              </div>

              <div className="mt-3 flex justify-center gap-2.5 pb-1">
                {images.map((img, i) => (
                  <button
                    type="button"
                    key={img.alt}
                    onClick={() => setActive(i)}
                    aria-label={`View image ${i + 1}`}
                    aria-pressed={i === active}
                    className={cn(
                      "relative size-14 overflow-hidden rounded-xl border bg-paper-soft transition-all duration-300 md:size-16",
                      i === active
                        ? "scale-105 border-ink/70 shadow-[0_8px_24px_-10px_oklch(0.145_0_0/45%)]"
                        : "border-hairline opacity-60 hover:opacity-100",
                    )}
                  >
                    <img src={img.src} alt="" loading="lazy" className="h-full w-full object-cover" />
                  </button>
                ))}
              </div>
            </div>
          </Reveal>

          {/* ============ Info ============ */}
          <Reveal delay={120} className="order-2 flex min-w-0 flex-col">
            <h2 className="display mt-6 text-[9.5vw] text-ink sm:text-[6.5vw] lg:text-[2.7vw]">
              {product.titleLines.map((line) => (
                <span key={line} className="block">
                  {line}
                </span>
              ))}
            </h2>

            <div className="mt-5 flex items-baseline gap-3">
              <span className="text-4xl font-extrabold tracking-tight text-ink md:text-5xl">
                {formatPrice(price)}
              </span>
              <span className="font-mono text-sm text-grey line-through">
                {formatPrice(compareAt)}
              </span>
            </div>

            <p className="mt-4 max-w-lg text-sm leading-relaxed text-grey">{description}</p>

            {/* Colour + quantity */}
            <div className="glass-frost mt-8 flex flex-col gap-6 rounded-2xl p-5 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <p className="label-mono text-grey">Colour</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {colors.map((c) => (
                    <button
                      type="button"
                      key={c.name}
                      onClick={() => setColor(c.name)}
                      aria-pressed={color === c.name}
                      className={cn(
                        "label-mono flex min-h-10 items-center gap-2.5 rounded-full border px-4 transition-all duration-300",
                        color === c.name
                          ? "border-ink bg-ink text-paper"
                          : "border-hairline text-grey hover:border-ink/40 hover:text-ink",
                      )}
                    >
                      <span
                        className={cn("size-2.5 rounded-full ring-1", color === c.name ? "ring-white/40" : "ring-ink/15")}
                        style={{ backgroundColor: c.swatch }}
                      />
                      {c.name}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <p className="label-mono text-grey">Quantity</p>
                <div className="mt-3 inline-flex items-center rounded-full border border-hairline bg-paper/70">
                  <button
                    type="button"
                    aria-label="Decrease quantity"
                    onClick={() => setQty((q) => Math.max(1, q - 1))}
                    className="flex size-10 items-center justify-center rounded-full text-ink transition-colors hover:bg-paper-soft"
                  >
                    <Minus className="size-4" strokeWidth={1.5} />
                  </button>
                  <span className="w-9 text-center font-mono text-sm text-ink">{qty}</span>
                  <button
                    type="button"
                    aria-label="Increase quantity"
                    onClick={() => setQty((q) => Math.min(10, q + 1))}
                    className="flex size-10 items-center justify-center rounded-full text-ink transition-colors hover:bg-paper-soft"
                  >
                    <Plus className="size-4" strokeWidth={1.5} />
                  </button>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="mt-6 flex flex-col gap-3 sm:flex-row">
              <MagneticButton variant="solid-dark" className="flex-1" onClick={addToCart} disabled={loading || isLoading || !available}>
                {loading ? "Loading…" : available ? "Add to Cart" : "Sold Out"}
              </MagneticButton>
              <MagneticButton variant="ghost-dark" className="flex-1" onClick={buyNow} disabled={loading || isLoading || !available}>
                Buy Now
              </MagneticButton>
            </div>

            {/* Specs */}
            <div className="glass-frost mt-6 rounded-2xl p-5 md:p-6">
              <p className="label-mono text-ink">Specifications</p>
              <dl className="mt-4">
                {product.specs.map((s) => (
                  <div
                    key={s.label}
                    className="flex items-baseline justify-between gap-4 border-b border-hairline py-2.5 last:border-b-0"
                  >
                    <dt className="label-mono shrink-0 text-grey">{s.label}</dt>
                    <dd className="text-right text-xs font-medium text-ink">{s.value}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
