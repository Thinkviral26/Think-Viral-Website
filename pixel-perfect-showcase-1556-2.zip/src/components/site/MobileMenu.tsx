import { useEffect } from "react";
import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";
import { navLinks } from "./Navbar";

export function MobileMenu({ open, onClose }: { open: boolean; onClose: () => void }) {
  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <div
      aria-hidden={!open}
      className={cn(
        "fixed inset-0 z-40 bg-ink/70 backdrop-blur-2xl backdrop-saturate-150 transition-[clip-path,opacity] duration-600 md:hidden",
        open ? "pointer-events-auto opacity-100" : "pointer-events-none opacity-0",
      )}
      style={{ clipPath: open ? "inset(0 0 0 0)" : "inset(0 0 100% 0)" }}
    >
      <div className="grid-texture absolute inset-0 opacity-60" />
      <nav className="relative flex h-full flex-col justify-center gap-2 px-6 pt-16">
        {navLinks.map((link, i) => {
          const className = cn(
            "display border-b border-hairline-dark py-5 text-[13vw] text-paper transition-all duration-600",
            open ? "translate-y-0 opacity-100" : "translate-y-6 opacity-0",
          );
          const style = { transitionDelay: open ? `${160 + i * 80}ms` : "0ms" };
          return "to" in link ? (
            <Link key={link.label} to={link.to} onClick={onClose} style={style} className={className}>
              {link.label}
            </Link>
          ) : (
            <a key={link.label} href={link.href} onClick={onClose} style={style} className={className}>
              {link.label}
            </a>
          );
        })}
        <p
          style={{ transitionDelay: open ? "520ms" : "0ms" }}
          className={cn(
            "label-mono mt-10 text-grey transition-opacity duration-600",
            open ? "opacity-100" : "opacity-0",
          )}
        >
          Wireless audio · Everyday tech · India
        </p>
      </nav>
    </div>
  );
}
