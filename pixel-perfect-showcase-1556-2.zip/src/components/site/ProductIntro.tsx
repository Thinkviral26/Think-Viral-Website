import { Reveal } from "./Reveal";

export function ProductIntro() {
  return (
    <section id="intro" className="relative bg-paper-soft py-16 md:py-24">
      <div className="grid-texture-light absolute inset-0 opacity-50" />

      <div className="relative mx-auto max-w-[1600px] px-5 md:px-10">
        <Reveal>
          <p className="label-mono text-grey">The Earbuds / 002</p>
        </Reveal>

        <div className="mt-6 grid gap-6 lg:grid-cols-[1.2fr_1fr] lg:items-end">
          <Reveal>
            <h2 className="display text-[11vw] text-ink sm:text-[8vw] lg:text-[5.4vw]">
              <span className="block">Meet your</span>
              <span className="block">Everyday Audio.</span>
            </h2>
          </Reveal>
          <Reveal delay={120}>
            <p className="max-w-md text-base leading-relaxed text-grey md:text-lg">
              Thoughtfully designed for the everyday. A compact wireless setup made for commutes,
              study sessions, calls and everything between.
            </p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
