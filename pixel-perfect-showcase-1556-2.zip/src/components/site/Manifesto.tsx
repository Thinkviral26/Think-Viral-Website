import { Reveal } from "./Reveal";

export function Manifesto() {
  return (
    <section id="about" className="relative overflow-hidden bg-ink py-24 md:py-36">
      <div className="grid-texture absolute inset-0" />
      <div className="ambient-rgb pointer-events-none absolute inset-x-[10%] top-[10%] h-[80%] opacity-30" />

      <div className="relative mx-auto max-w-[1600px] px-5 md:px-10">
        <Reveal>
          <p className="label-mono text-grey">Manifesto / 005</p>
          <h2 className="display mt-8 max-w-5xl text-[12vw] text-paper sm:text-[9vw] lg:text-[5.8vw]">
            <span className="block">Tech doesn't</span>
            <span className="block">need to be</span>
            <span className="outline-light block">Complicated.</span>
          </h2>
        </Reveal>

        <Reveal delay={140}>
          <p className="mt-12 max-w-2xl text-base leading-relaxed text-grey md:text-lg">
            We believe everyday technology should look good, work well and make sense for your
            wallet. THINKVIRAL brings useful tech products to everyday people — without unnecessary
            complexity.
          </p>
          <p className="label-mono mt-16 border-t border-hairline-dark pt-6 text-paper/60">
            Designed for the everyday / 2026
          </p>
        </Reveal>
      </div>
    </section>
  );
}
