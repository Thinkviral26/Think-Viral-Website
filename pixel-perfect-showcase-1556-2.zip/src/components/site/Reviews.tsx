import { Star } from "lucide-react";
import { cn } from "@/lib/utils";
import { Reveal } from "./Reveal";

export type Review = {
  name: string;
  rating: number;
  body: string;
  date: string;
  image?: string;
};

/**
 * PLACEHOLDER REVIEWS — these are not real customer reviews.
 * Replace this array with genuine reviews before publishing.
 */
export const placeholderReviews: Review[] = [
  { name: "Customer name", rating: 5, body: "Review text goes here.", date: "DD MMM YYYY" },
  { name: "Customer name", rating: 5, body: "Review text goes here.", date: "DD MMM YYYY" },
  { name: "Customer name", rating: 5, body: "Review text goes here.", date: "DD MMM YYYY" },
];

export function Reviews({ reviews = placeholderReviews }: { reviews?: Review[] }) {
  return (
    <section className="bg-paper-soft py-20 md:py-32">
      <div className="mx-auto max-w-[1600px] px-5 md:px-10">
        <Reveal>
          <p className="label-mono text-grey">Reviews / 006</p>
          <h2 className="display mt-6 text-[11vw] text-ink sm:text-[8vw] lg:text-[5.4vw]">
            <span className="block">What our</span>
            <span className="block">Customers say.</span>
          </h2>
          <p className="label-mono mt-8 text-grey">
            Placeholder slots — replace with verified customer reviews
          </p>
        </Reveal>

        <div className="mt-12 grid border-t border-l border-hairline md:mt-16 md:grid-cols-3">
          {reviews.map((review, i) => (
            <ReviewCard key={i} review={review} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

function ReviewCard({ review, index }: { review: Review; index: number }) {
  return (
    <Reveal
      delay={index * 90}
      className="flex flex-col justify-between gap-8 border-r border-b border-hairline bg-paper p-8 md:p-10"
    >
      <div>
        <div className="flex gap-1.5">
          {Array.from({ length: 5 }).map((_, i) => (
            <Star
              key={i}
              className={cn("size-3.5", i < review.rating ? "fill-ink text-ink" : "text-hairline")}
              strokeWidth={0}
            />
          ))}
        </div>
        <p className="mt-6 text-lg leading-relaxed text-ink">{review.body}</p>
      </div>

      <div className="flex items-center gap-3">
        {review.image ? (
          <img
            src={review.image}
            alt={review.name}
            loading="lazy"
            className="size-9 rounded-full object-cover"
          />
        ) : (
          <span className="size-9 rounded-full bg-paper-soft ring-1 ring-hairline" />
        )}
        <div>
          <p className="label-mono text-ink">{review.name}</p>
          <p className="mt-1 font-mono text-[11px] text-grey">{review.date}</p>
        </div>
      </div>
    </Reveal>
  );
}
