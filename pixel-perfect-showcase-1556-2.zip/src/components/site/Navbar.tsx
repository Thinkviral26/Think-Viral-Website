import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Menu, Search, ShoppingBag, User, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { useCart } from "@/lib/cart";
import { Wordmark } from "./Wordmark";
import { MobileMenu } from "./MobileMenu";

export const navLinks = [
  { label: "SHOP", to: "/shop" as const },
  { label: "FEATURES", href: "#features" },
  { label: "ABOUT", href: "#about" },
  { label: "FAQ", href: "#faq" },
];

export function Navbar({ alwaysSolid = false }: { alwaysSolid?: boolean }) {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const { count, open } = useCart();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const solid = scrolled || alwaysSolid;

  return (
    <>
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-50 text-paper transition-[height,background-color,border-color,backdrop-filter,box-shadow] duration-500",
          solid
            ? "h-14 border-b border-white/10 bg-ink/55 shadow-[inset_0_1px_0_oklch(1_0_0/8%),0_20px_50px_-30px_oklch(0_0_0/70%)] backdrop-blur-2xl backdrop-saturate-150 md:h-16"
            : "h-16 border-b border-transparent bg-transparent md:h-20",
        )}
      >
        <div className="mx-auto flex h-full max-w-[1600px] items-center justify-between px-5 md:px-10">
          <Link to="/" aria-label="THINKVIRAL home">
            <Wordmark className="w-28 md:w-32" />
          </Link>

          <nav className="hidden items-center gap-10 md:flex">
            {navLinks.map((link) =>
              "to" in link ? (
                <Link
                  key={link.label}
                  to={link.to}
                  className="label-mono text-paper/70 transition-colors hover:text-paper"
                  activeProps={{ className: "label-mono text-paper" }}
                >
                  {link.label}
                </Link>
              ) : (
                <a
                  key={link.label}
                  href={link.href}
                  className="label-mono text-paper/70 transition-colors hover:text-paper"
                >
                  {link.label}
                </a>
              ),
            )}
          </nav>

          <div className="flex items-center gap-1 md:gap-2">
            <button
              aria-label="Search"
              className="flex size-11 items-center justify-center text-paper/70 transition-colors hover:text-paper"
            >
              <Search className="size-[18px]" strokeWidth={1.5} />
            </button>
            <button
              aria-label="Account"
              className="hidden size-11 items-center justify-center text-paper/70 transition-colors hover:text-paper md:flex"
            >
              <User className="size-[18px]" strokeWidth={1.5} />
            </button>
            <button
              aria-label="Open cart"
              onClick={open}
              className="relative flex size-11 items-center justify-center text-paper/70 transition-colors hover:text-paper"
            >
              <ShoppingBag className="size-[18px]" strokeWidth={1.5} />
              {count > 0 && (
                <span className="absolute top-1.5 right-1 flex min-w-4 items-center justify-center bg-rgb-blue px-1 font-mono text-[10px] leading-4 text-paper">
                  {count}
                </span>
              )}
            </button>
            <button
              aria-label={menuOpen ? "Close menu" : "Open menu"}
              onClick={() => setMenuOpen((v) => !v)}
              className="flex size-11 items-center justify-center text-paper md:hidden"
            >
              {menuOpen ? (
                <X className="size-5" strokeWidth={1.5} />
              ) : (
                <Menu className="size-5" strokeWidth={1.5} />
              )}
            </button>
          </div>
        </div>
      </header>

      <MobileMenu open={menuOpen} onClose={() => setMenuOpen(false)} />
    </>
  );
}
