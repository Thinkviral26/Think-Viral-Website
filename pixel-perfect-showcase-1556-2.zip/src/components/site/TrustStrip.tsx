import { Headphones, Lock, ShieldCheck, Truck } from "lucide-react";
import { Reveal } from "./Reveal";

const items = [
  { icon: Lock, label: "Secure Checkout" },
  { icon: ShieldCheck, label: "Quality Checked" },
  { icon: Truck, label: "Fast Shipping" },
  { icon: Headphones, label: "Customer Support" },
];

export function TrustStrip() {
  return (
    <section className="border-b border-hairline bg-paper">
      <div className="mx-auto grid max-w-[1600px] grid-cols-2 px-5 md:grid-cols-4 md:px-10">
        {items.map((item, i) => (
          <Reveal
            key={item.label}
            delay={i * 80}
            className={`flex items-center gap-3 py-7 md:justify-center ${
              i > 0 ? "md:border-l md:border-hairline" : ""
            } ${i % 2 === 1 ? "border-l border-hairline md:border-l" : ""}`}
          >
            <item.icon className="size-4 text-ink" strokeWidth={1.25} />
            <span className="label-mono text-ink">{item.label}</span>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
