import { lazy, Suspense, useEffect, useState } from "react";
import { ArrowRight } from "lucide-react";
import { useNavigate } from "@tanstack/react-router";
import { product } from "@/data/product";
import { MagneticButton } from "./MagneticButton";

export function Hero() {
  const [ready, setReady] = useState(false);
  const [mounted, setMounted] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const t = requestAnimationFrame(() => setReady(true));
    setMounted(true);
    return () => cancelAnimationFrame(t);
  }, []);

  const enter = (delay: number) => ({
    className: `transition-all duration-[1100ms] ease-[cubic-bezier(0.16,1,0.3,1)] ${
      ready ? "translate-y-0 opacity-100 blur-0" : "translate-y-8 opacity-0 blur-sm"
    }`,
    style: { transitionDelay: `${delay}ms` },
  });

  return (
    <section id="top" className="relative overflow-hidden bg-ink text-paper">
      <div className="grid-texture absolute inset-0" />
      <div className="ambient-rgb pointer-events-none absolute inset-x-0 top-[12%] h-[70%] opacity-45" />

      <div className="relative mx-auto grid max-w-[1600px] items-center gap-10 px-5 pt-28 pb-16 md:px-10 md:pt-36 md:pb-24 lg:grid-cols-[1.05fr_1fr] lg:gap-6 lg:pt-40">
        <div className="order-1">
          <p {...enter(100)}>
            <span className="label-mono text-grey">Wireless audio · Everyday tech · India</span>
          </p>

          <h1 className="display mt-7 text-[16vw] leading-[0.85] sm:text-[13vw] lg:text-[8.2vw]">
            {["Sound", "Without", "The Hype."].map((w, i) => (
              <span key={w} className="block overflow-hidden">
                <span
                  className={`block transition-transform duration-[1200ms] ease-[cubic-bezier(0.16,1,0.3,1)] ${
                    i === 1 ? "outline-light" : ""
                  } ${ready ? "translate-y-0" : "translate-y-[105%]"}`}
                  style={{ transitionDelay: `${250 + i * 120}ms` }}
                >
                  {w}
                </span>
              </span>
            ))}
          </h1>

          <p {...enter(700)}>
            <span className="mt-8 block max-w-md text-base leading-relaxed text-grey md:text-lg">
              Wireless audio built for everyday life — clean, minimal and uncomplicated.
            </span>
          </p>

          <div {...enter(850)}>
            <div className="mt-10 flex flex-col gap-3 sm:flex-row">
              <MagneticButton
                variant="solid-light"
                onClick={() => navigate({ to: "/product/$id", params: { id: product.id } })}
              >
                Shop Earbuds <ArrowRight className="size-4" strokeWidth={2} />
              </MagneticButton>
              <MagneticButton
                variant="ghost-light"
                onClick={() => navigate({ to: "/explore" })}
              >
                Explore <ArrowRight className="size-4" strokeWidth={2} />
              </MagneticButton>
            </div>
          </div>
        </div>

        <div className="relative order-2">
          <div
            className={`relative mx-auto aspect-square w-full max-w-[640px] transition-all duration-[1400ms] ease-[cubic-bezier(0.16,1,0.3,1)] ${
              ready ? "scale-100 opacity-100" : "scale-90 opacity-0"
            }`}
            style={{ perspective: "1400px", transitionDelay: "300ms" }}
          >
            <div
              className="ambient-rgb pointer-events-none absolute inset-[12%] opacity-60"
            />

            {/* Orbit rings */}
            <div className="pointer-events-none absolute inset-[6%] rounded-full border border-paper/10 hero-orbit" />
            <div className="pointer-events-none absolute inset-[18%] rounded-full border border-dashed border-paper/10 hero-orbit-rev" />

            <div className="absolute inset-0 z-[1]">
              {mounted ? (
                <Suspense fallback={<div className="h-full w-full" />}>
                  <HeroModelViewer />
                </Suspense>
              ) : null}
            </div>

            <span className="label-mono pointer-events-none absolute top-4 left-0 z-[2] text-grey">ANC</span>
            <span className="label-mono pointer-events-none absolute top-4 right-0 z-[2] text-grey">Sound System</span>
          </div>
        </div>
      </div>

      <div className="relative flex justify-center pb-10">
        <div className="flex flex-col items-center gap-3">
          <span className="label-mono text-grey">Scroll</span>
          <span className="h-10 w-px bg-linear-to-b from-paper/50 to-transparent" />
        </div>
      </div>
    </section>
  );
}

const HeroModelViewer = lazy(() => import("./HeroModelViewer"));
