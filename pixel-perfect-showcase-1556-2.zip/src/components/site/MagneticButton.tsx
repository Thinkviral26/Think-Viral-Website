import { useRef, type ButtonHTMLAttributes, type ReactNode } from "react";
import { cn } from "@/lib/utils";
import { useReducedMotion } from "@/hooks/use-motion-prefs";

type Variant = "solid-light" | "solid-dark" | "ghost-light" | "ghost-dark";

const variants: Record<Variant, string> = {
  "solid-light": "bg-paper text-ink hover:bg-paper",
  "solid-dark": "bg-ink text-paper hover:bg-ink-soft",
  "ghost-light": "border border-hairline-dark text-paper hover:border-rgb-blue",
  "ghost-dark": "border border-hairline text-ink hover:border-rgb-blue",
};

type Props = ButtonHTMLAttributes<HTMLButtonElement> & {
  children: ReactNode;
  variant?: Variant;
  strength?: number;
};

/** Button that subtly follows the cursor and lifts with a soft RGB shadow. */
export function MagneticButton({
  children,
  className,
  variant = "solid-light",
  strength = 8,
  ...rest
}: Props) {
  const ref = useRef<HTMLButtonElement>(null);
  const reduced = useReducedMotion();

  const onMove = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (reduced) return;
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const x = ((e.clientX - r.left) / r.width - 0.5) * strength * 2;
    const y = ((e.clientY - r.top) / r.height - 0.5) * strength;
    el.style.transform = `translate3d(${x}px, ${y - 2}px, 0)`;
  };

  const onLeave = () => {
    const el = ref.current;
    if (el) el.style.transform = "";
  };

  return (
    <button
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      className={cn(
        "label-mono hover-rgb-shadow inline-flex min-h-12 items-center justify-center gap-3 px-7 py-4 font-medium",
        variants[variant],
        className,
      )}
      {...rest}
    >
      {children}
    </button>
  );
}
