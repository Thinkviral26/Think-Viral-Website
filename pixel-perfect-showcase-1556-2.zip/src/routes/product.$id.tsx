import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Toaster } from "sonner";
import { ArrowLeft } from "lucide-react";

import { CartProvider } from "@/lib/cart";
import { product } from "@/data/product";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { CartDrawer } from "@/components/site/CartDrawer";
import { ProductPurchase } from "@/components/site/ProductPurchase";

export const Route = createFileRoute("/product/$id")({
  loader: ({ params }) => {
    if (params.id !== product.id) throw notFound();
    return { item: product };
  },
  head: ({ loaderData }) => {
    const title = `${loaderData?.item.name ?? "Product"} — THINKVIRAL`;
    const description =
      loaderData?.item.description ??
      "THINKVIRAL product details, specifications and purchase options.";
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  notFoundComponent: ProductNotFound,
  component: ProductDetailPage,
});

function ProductDetailPage() {
  return (
    <CartProvider>
      <Navbar alwaysSolid />
      <div className="fixed inset-x-0 top-14 z-40 border-b border-white/10 bg-black md:top-16">
        <Link
          to="/shop"
          className="label-mono group flex h-10 items-center justify-center gap-3 px-5 text-white transition-colors duration-300 hover:text-rgb-blue focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-white active:bg-white/5 md:h-11 md:px-10"
        >
          <ArrowLeft
            className="size-4 transition-transform duration-300 group-hover:-translate-x-1"
            strokeWidth={1.5}
          />
          BACK TO SHOP
        </Link>
      </div>
      <main className="bg-paper pt-24 md:pt-[6.75rem]">
        <ProductPurchase />
      </main>
      <Footer />
      <CartDrawer />
      <Toaster
        position="top-center"
        toastOptions={{
          className: "label-mono",
          style: {
            background: "oklch(0.145 0 0)",
            color: "oklch(1 0 0)",
            border: "1px solid oklch(1 0 0 / 12%)",
            borderRadius: "0",
          },
        }}
      />
    </CartProvider>
  );
}

function ProductNotFound() {
  return (
    <main className="flex min-h-svh flex-col items-center justify-center gap-6 bg-ink px-6 text-center text-paper">
      <p className="label-mono text-rgb-blue">404 / Product</p>
      <h1 className="display text-4xl md:text-6xl">PRODUCT NOT FOUND</h1>
      <p className="max-w-md text-sm leading-relaxed text-grey">
        The product you're looking for doesn't exist or has been removed.
      </p>
      <Link
        to="/shop"
        className="label-mono border border-paper/25 px-6 py-3 transition-colors hover:border-paper hover:bg-paper hover:text-ink"
      >
        Back to shop
      </Link>
    </main>
  );
}
