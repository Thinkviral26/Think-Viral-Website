import { createFileRoute, Link } from "@tanstack/react-router";
import { Toaster } from "sonner";
import { ArrowRight, Compass, Ear, Heart, ShieldCheck, Sparkles, Zap } from "lucide-react";

import { CartProvider } from "@/lib/cart";
import { product, formatPrice } from "@/data/product";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { CartDrawer } from "@/components/site/CartDrawer";
import { Reveal } from "@/components/site/Reveal";
import { Wordmark } from "@/components/site/Wordmark";

const title = "Explore THINKVIRAL — The Brand";
const description =
  "Get to know THINKVIRAL. Who we are, what we stand for, and the everyday tech we build — starting with our TWS wireless earbuds with ANC.";

export const Route = createFileRoute("/explore")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ExplorePage,
});

function ExplorePage() {
  return (
    <CartProvider>
      <Navbar />
      <main className="bg-ink text-paper">
        <ExploreHero />
        <StorySection />
        <PrinciplesSection />
        <ProductSpotlight />
        <WhatsNext />
      </main>
      <Footer />
      <CartDrawer />
      <Toaster
        position="top-center"
        toastOptions={{
          className: "label-mono",
          style: {
            background: "oklch(0.145 0 0)",
            color: "oklch(1 0 0)",
            border: "1px solid oklch(1 0 0 / 12%)",
            borderRadius: "0",
          },
        }}
      />
    </CartProvider>
  );
}

function ExploreHero() {
  return (
    <section className="relative overflow-hidden px-5 pt-36 pb-20 md:px-10 md:pt-44 md:pb-28">
      <div className="grid-texture absolute inset-0 opacity-50" />
      <div
        aria-hidden
        className="absolute -top-40 left-1/2 h-[420px] w-[760px] -translate-x-1/2 rounded-full bg-rgb-blue/15 blur-[140px]"
      />
      <div className="relative mx-auto max-w-[1600px]">
        <Reveal>
          <p className="label-mono text-rgb-blue">The Brand / Explore</p>
        </Reveal>
        <Reveal delay={100}>
          <h1 className="display mt-6 max-w-5xl text-[13vw] leading-[0.92] md:text-[7vw]">
            ALL THINGS
            <br />
            <span className="outline-light">THINKVIRAL.</span>
          </h1>
        </Reveal>
        <Reveal delay={200}>
          <p className="mt-8 max-w-xl text-base leading-relaxed text-grey md:text-lg">
            A small Indian tech brand with one simple idea — everyday audio and
            gadgets, built honestly and priced fairly. No hype. Just things
            that work.
          </p>
        </Reveal>
        <Reveal delay={300}>
          <div className="mt-10 flex flex-wrap items-center gap-x-10 gap-y-4">
            <div className="flex items-center gap-3">
              <Wordmark className="h-6 w-auto opacity-90" />
              <span className="label-mono text-grey">Est. 2026 · India</span>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function StorySection() {
  return (
    <section className="px-5 pb-20 md:px-10 md:pb-28">
      <div className="mx-auto grid max-w-[1600px] gap-12 border-t border-hairline-dark pt-14 lg:grid-cols-[1fr_1.2fr] lg:gap-20">
        <Reveal>
          <h2 className="display text-3xl leading-tight md:text-5xl">
            SOUND WITHOUT
            <br />
            THE HYPE.
          </h2>
        </Reveal>
        <Reveal delay={120}>
          <div className="space-y-6 text-base leading-relaxed text-grey md:text-lg">
            <p>
              THINKVIRAL started with a familiar frustration: good everyday
              tech is either overpriced, over-marketed, or both. We wanted the
              opposite — clean, minimal products that do their job well and
              cost what they should.
            </p>
            <p>
              We design for real life. Commutes, study sessions, calls, workouts
              and everything between. Every product starts as something we want
              to use ourselves, then we strip away everything unnecessary until
              only the good part remains.
            </p>
            <p>
              We're beginning with audio, and we're just getting started. One
              product today, more on the way — each built with the same care.
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

const principles = [
  {
    icon: Ear,
    title: "MADE FOR EVERYDAY",
    body: "Compact, comfortable and reliable — designed around how you actually live, not a spec sheet.",
  },
  {
    icon: ShieldCheck,
    title: "HONEST SPECS",
    body: "What we say is what you get. No inflated claims, no fake features, no marketing tricks.",
  },
  {
    icon: Zap,
    title: "FAIRLY PRICED",
    body: "Serious value without compromise. Premium feel at a price that makes sense.",
  },
  {
    icon: Heart,
    title: "BUILT TO LAST",
    body: "Durable materials, careful engineering and support you can actually reach.",
  },
];

function PrinciplesSection() {
  return (
    <section className="px-5 pb-20 md:px-10 md:pb-28">
      <div className="mx-auto max-w-[1600px]">
        <Reveal>
          <p className="label-mono text-grey">What we stand for / 001</p>
        </Reveal>
        <Reveal delay={80}>
          <h2 className="display mt-4 text-3xl leading-tight md:text-5xl">
            FOUR SIMPLE RULES.
          </h2>
        </Reveal>
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {principles.map((p, i) => (
            <Reveal key={p.title} delay={i * 100}>
              <article className="glass-dark group flex h-full flex-col gap-4 p-7 transition-transform duration-500 ease-out hover:-translate-y-1">
                <p.icon
                  className="size-6 text-rgb-blue transition-transform duration-500 group-hover:scale-110"
                  strokeWidth={1.5}
                />
                <h3 className="display text-base md:text-lg">{p.title}</h3>
                <p className="text-sm leading-relaxed text-grey">{p.body}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function ProductSpotlight() {
  return (
    <section className="px-5 pb-20 md:px-10 md:pb-28">
      <div className="mx-auto max-w-[1600px]">
        <Reveal>
          <p className="label-mono text-grey">Our first product</p>
        </Reveal>
        <Reveal delay={80}>
          <h2 className="display mt-4 text-3xl leading-tight md:text-5xl">
            WHERE IT STARTED.
          </h2>
        </Reveal>
        <Reveal delay={150}>
          <Link
            to="/product/$id"
            params={{ id: product.id }}
            aria-label={`View details for ${product.name}`}
            className="group glass-dark mt-10 grid overflow-hidden md:grid-cols-2"
          >
            <div className="relative aspect-square overflow-hidden">
              <img
                src={product.images[0]?.src}
                alt={product.images[0]?.alt}
                className="h-full w-full object-contain p-10 transition-transform duration-700 ease-out group-hover:scale-105"
              />
            </div>
            <div className="flex flex-col justify-center gap-5 border-t border-white/10 p-8 md:border-t-0 md:border-l md:p-12">
              <h3 className="display text-2xl leading-tight md:text-3xl">
                {product.titleLines.join(" ")}
              </h3>
              <p className="max-w-md text-sm leading-relaxed text-grey md:text-base">
                {product.description}
              </p>
              <div className="flex items-center gap-6">
                <span className="text-2xl font-semibold">
                  {formatPrice(product.price)}
                </span>
                <span className="text-grey line-through">
                  {formatPrice(product.compareAtPrice)}
                </span>
              </div>
              <span className="label-mono mt-2 inline-flex w-fit items-center gap-2 border border-paper/25 px-6 py-3 transition-colors group-hover:border-rgb-blue group-hover:text-rgb-blue">
                View the earbuds
                <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1" strokeWidth={2} />
              </span>
            </div>
          </Link>
        </Reveal>
      </div>
    </section>
  );
}

const roadmap = [
  {
    icon: Compass,
    label: "01",
    title: "MORE AUDIO",
    body: "New ways to listen — over-ear, speakers and more, built to the same standard.",
  },
  {
    icon: Sparkles,
    label: "02",
    title: "EVERYDAY GADGETS",
    body: "Small, useful tech for your desk, your bag and your day.",
  },
];

function WhatsNext() {
  return (
    <section className="px-5 pb-24 md:px-10 md:pb-32">
      <div className="mx-auto max-w-[1600px] border-t border-hairline-dark pt-14">
        <Reveal>
          <p className="label-mono text-grey">The road ahead / 002</p>
        </Reveal>
        <Reveal delay={80}>
          <h2 className="display mt-4 text-3xl leading-tight md:text-5xl">
            WHAT'S NEXT.
          </h2>
        </Reveal>
        <div className="mt-12 grid gap-4 md:grid-cols-2">
          {roadmap.map((r, i) => (
            <Reveal key={r.title} delay={i * 120}>
              <div className="glass-dark flex h-full flex-col gap-4 border-dashed p-8">
                <div className="flex items-center justify-between">
                  <r.icon className="size-6 text-rgb-blue" strokeWidth={1.5} />
                  <span className="label-mono text-grey">{r.label}</span>
                </div>
                <h3 className="display text-lg md:text-xl">{r.title}</h3>
                <p className="max-w-sm text-sm leading-relaxed text-grey">{r.body}</p>
              </div>
            </Reveal>
          ))}
        </div>
        <Reveal delay={200}>
          <div className="mt-14 flex flex-col items-start justify-between gap-6 border-t border-hairline-dark pt-10 md:flex-row md:items-center">
            <p className="max-w-md text-sm leading-relaxed text-grey">
              Ready to try our first product?
            </p>
            <Link
              to="/shop"
              className="label-mono inline-flex items-center gap-2 bg-paper px-6 py-3 text-ink transition-colors hover:bg-rgb-blue hover:text-paper"
            >
              Visit the shop
              <ArrowRight className="size-4" strokeWidth={2} />
            </Link>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
